package com.example.homework2_b11109012

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.Card
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.res.stringResource
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.homework2_b11109012.ui.theme.Homework2_B11109012Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Homework2_B11109012Theme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AttractionsApp()
                }
            }
        }
    }
}

data class Attraction(@StringRes val stringResourceId: Int, @DrawableRes val imageResourceId: Int, @StringRes val descriptionResourceId: Int, @StringRes val locationResourceId: Int)

class Datasource {
    fun loadAttractions(): List<Attraction> {
        return listOf(
            Attraction(R.string.caption1, R.drawable.attraction1, R.string.description1, R.string.location1),
            Attraction(R.string.caption2, R.drawable.attraction2, R.string.description2, R.string.location2),
            Attraction(R.string.caption3, R.drawable.attraction3, R.string.description3, R.string.location3),
            Attraction(R.string.caption4, R.drawable.attraction4, R.string.description4, R.string.location4),
            Attraction(R.string.caption5, R.drawable.attraction5, R.string.description5, R.string.location5)
        )
    }
}

@Composable
fun AttractionCard(attraction: Attraction, modifier: Modifier) {
    Card (modifier = modifier) {
        Column {
            Image(
                painter = painterResource(attraction.imageResourceId),
                contentDescription = stringResource(attraction.stringResourceId),
                modifier = Modifier
                    .height(200.dp),
                contentScale = ContentScale.Crop
            )
            Text(
                text = LocalContext.current.getString(attraction.stringResourceId),
                modifier = Modifier
                    .padding(16.dp),
                style = MaterialTheme.typography.headlineSmall,
                fontFamily = FontFamily.Serif
            )
        }
    }
}

@Composable
fun AttractionsApp() {
    val navController = rememberNavController()
    NavHost(navController, startDestination = "attractionList") {
        composable("attractionList") {
            AttractionList(navController = navController)
        }
        composable("attractionDetails/{attractionId}",
            arguments = listOf(navArgument("attractionId") { type = NavType.IntType })
        ){
                backStackEntry ->
            val attractionId = backStackEntry.arguments?.getInt("attractionId") ?: return@composable
            val attraction = Datasource().loadAttractions().find { it.stringResourceId == attractionId }
            if (attraction != null) {
                DescriptionPage(attraction = attraction, navController = navController)
            }
        }
    }
}


@Composable
fun DescriptionPage(attraction: Attraction, navController: NavController) {
    val context = LocalContext.current

    Row(
        modifier = Modifier.fillMaxWidth()
    ) {
        IconButton(
            onClick = { navController.navigateUp() }
        ) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Back"
            )
        }
    }

    Column (
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxSize()
            .padding(30.dp)
    ) {
        Image(
            painter = painterResource(attraction.imageResourceId),
            contentDescription = stringResource(attraction.stringResourceId),
            modifier = Modifier
                .height(200.dp)
                .clip(RoundedCornerShape(8.dp)),
            contentScale = ContentScale.Crop
        )

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = stringResource(attraction.stringResourceId),
            style = MaterialTheme.typography.headlineMedium,
            fontFamily = FontFamily.Serif,
            modifier = Modifier
                .padding(top = 16.dp),
        )

        Spacer(modifier = Modifier.height(60.dp))

        Text(
            text = stringResource(attraction.descriptionResourceId),
            style = MaterialTheme.typography.bodyMedium,
            fontFamily = FontFamily.Serif,
            modifier = Modifier.padding(
                top = 10.dp,
                start = 10.dp,
                end = 10.dp,
                bottom = 10.dp),
            textAlign = TextAlign.Justify
        )

        Button(
            onClick = {
                val gmmIntentUri = Uri.parse(attraction.locationResourceId.toString())
                val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
                mapIntent.setPackage("com.google.android.apps.maps")
                ContextCompat.startActivity(context, mapIntent, null)
            },
            modifier = Modifier.padding(top = 16.dp)
        ) {
            Text(text = "Open in Google Maps")
        }
    }
}


@Composable
fun AttractionList(navController: NavHostController) {
    val attractionList = Datasource().loadAttractions()
    val modifier = Modifier
    LazyColumn (modifier = modifier) {
        items(attractionList){attraction ->
            AttractionCard(
                attraction = attraction,
                modifier = Modifier
                    .padding(20.dp)
                    .clickable { navController.navigate("attractionDetails/${attraction.stringResourceId}") }
            )
        }
    }
}



@Preview(showBackground = true)
@Composable
fun AttractionAppPreview() {
    Homework2_B11109012Theme {
        AttractionsApp()
    }
}

